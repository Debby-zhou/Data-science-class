# 2021-NCKU-IDS-HW6
<pre>
This is a bonus part of your homework6, if all the team members participate in the submission of the homework6, 
i.e., each of the team member has push something to the homework6 repository, 
then you will get 5% bonus credit in this homework.
</pre>
